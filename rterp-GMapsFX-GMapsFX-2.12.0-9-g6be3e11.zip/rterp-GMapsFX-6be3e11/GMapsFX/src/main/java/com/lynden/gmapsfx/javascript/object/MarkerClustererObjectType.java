package com.lynden.gmapsfx.javascript.object;

/**
 * User: twalcari
 * Date: 1/9/2015
 * Time: 12:04
 */
public interface MarkerClustererObjectType {

    public static final String MARKER_CLUSTERER = "MarkerClusterer";

}